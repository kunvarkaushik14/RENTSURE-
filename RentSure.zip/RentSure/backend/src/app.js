
const express = require("express");
const cors = require("cors");
const { rateLimit } = require("express-rate-limit");
const propertyRoutes = require("./routes/propertyRoutes");
const healthRoutes = require("./routes/healthRoutes");
const calculatorRoutes = require("./routes/calculatorRoutes");
const authRoutes = require("./routes/authRoutes");

const app = express();
const swaggerUi = require("swagger-ui-express");
const swaggerSpec = require("./config/swagger");
app.use(
  cors({
    origin: process.env.CLIENT_URL || "http://localhost:5173",
  })
);

app.use(express.json({ limit: "1mb" }));

app.get("/", (req, res) => {
  res.json({
    name: "RentSure API",
    version: "1.0.0",
    status: "running",
  });
});

app.use("/api/health", healthRoutes);
app.use("/api/calculator", calculatorRoutes);

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 20,
  standardHeaders: "draft-8",
  legacyHeaders: false,
  message: {
    success: false,
    message: "Too many authentication attempts. Please try again later.",
  },
});

app.use("/api/auth", authLimiter, authRoutes);

app.use((err, req, res, next) => {
  console.error("API error:", err.message);

  if (res.headersSent) {
    return next(err);
  }

  return res.status(500).json({
    success: false,
    message: "An unexpected server error occurred.",
  });
});
app.use(
  "/api-docs",
  swaggerUi.serve,
  swaggerUi.setup(swaggerSpec)
);
app.use("/api/properties", propertyRoutes);
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: "API route not found.",
  });
});

module.exports = app;
