
import { useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  ArrowLeft,
  Building2,
  Check,
  CircleAlert,
  Edit3,
  MapPin,
  Plus,
  RefreshCw,
  Save,
  Trash2,
  X,
} from "lucide-react";
import api from "./api";
import { useAuth } from "./AuthContext";
import "./PropertiesPage.css";

const emptyForm = {
  title: "",
  propertyType: "flat",
  description: "",
  address: "",
  city: "",
  monthlyRent: "",
  securityDeposit: "",
  bedrooms: "",
  bathrooms: "",
  area: "",
  furnishing: "unfurnished",
  amenities: "",
};

const money = (value) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(Number(value) || 0);

export default function LandlordPropertiesPage() {
  const { user } = useAuth();
  const [properties, setProperties] = useState([]);
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [deletingId, setDeletingId] = useState(null);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  const loadProperties = useCallback(async () => {
    setLoading(true);
    setError("");

    try {
      const result = await api.get("/properties/mine");
      setProperties(Array.isArray(result.properties) ? result.properties : []);
    } catch (err) {
      setError(err.message || "Unable to load your properties.");
      setProperties([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadProperties();
  }, [loadProperties]);

  function updateField(event) {
    const { name, value } = event.target;
    setForm((current) => ({ ...current, [name]: value }));
  }

  function startEditing(property) {
    setEditingId(property.id);
    setForm({
      title: property.title || "",
      propertyType: property.propertyType || "flat",
      description: property.description || "",
      address: property.address || "",
      city: property.city || "",
      monthlyRent: String(property.monthlyRent ?? ""),
      securityDeposit: String(property.securityDeposit ?? ""),
      bedrooms: String(property.bedrooms ?? ""),
      bathrooms: String(property.bathrooms ?? ""),
      area: String(property.area ?? ""),
      furnishing: property.furnishing || "unfurnished",
      amenities: Array.isArray(property.amenities)
        ? property.amenities.join(", ")
        : property.amenities || "",
    });
    setNotice("");
    setError("");

    document.getElementById("property-editor")?.scrollIntoView({
      behavior: "smooth",
      block: "start",
    });
  }

  function resetForm() {
    setEditingId(null);
    setForm(emptyForm);
  }

  async function handleSubmit(event) {
    event.preventDefault();
    setError("");
    setNotice("");

    const monthlyRent = Number(form.monthlyRent);
    const securityDeposit = Number(form.securityDeposit);

    if (!Number.isFinite(monthlyRent) || monthlyRent <= 0) {
      setError("Enter a valid monthly rent greater than zero.");
      return;
    }

    if (!Number.isFinite(securityDeposit) || securityDeposit < 0) {
      setError("Enter a valid non-negative security deposit.");
      return;
    }

    const optionalNumber = (value) =>
      value === "" ? null : Number(value);

    const payload = {
      title: form.title.trim(),
      propertyType: form.propertyType,
      description: form.description.trim(),
      address: form.address.trim(),
      city: form.city.trim(),
      monthlyRent,
      securityDeposit,
      bedrooms: optionalNumber(form.bedrooms),
      bathrooms: optionalNumber(form.bathrooms),
      area: optionalNumber(form.area),
      furnishing: form.furnishing,
      amenities: form.amenities
        .split(",")
        .map((item) => item.trim())
        .filter(Boolean),
    };

    if (
      !payload.title ||
      !payload.address ||
      !payload.city
    ) {
      setError("Please fill in the title, address, and city.");
      return;
    }

    setSaving(true);

    try {
      const path = editingId
        ? `/properties/${editingId}`
        : "/properties";

      const result = editingId
        ? await api.put(path, payload)
        : await api.post(path, payload);

      setNotice(
        result.message ||
          (editingId
            ? "Property updated successfully."
            : "Property created successfully.")
      );

      resetForm();
      await loadProperties();
    } catch (err) {
      setError(err.message || "Unable to save this property.");
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(property) {
    const confirmed = window.confirm(
      `Delete "${property.title}"? This action cannot be undone.`
    );

    if (!confirmed) return;

    setError("");
    setNotice("");
    setDeletingId(property.id);

    try {
      const result = await api.delete(`/properties/${property.id}`);

      setNotice(result.message || "Property deleted successfully.");

      if (String(editingId) === String(property.id)) {
        resetForm();
      }

      await loadProperties();
    } catch (err) {
      setError(err.message || "Unable to delete this property.");
    } finally {
      setDeletingId(null);
    }
  }

  const isLandlord = user?.role === "landlord";

  if (!isLandlord) {
    return (
      <main className="property-page">
        <header className="property-topbar">
          <Link to="/" className="property-brand">
            <span className="property-brand-icon">
              <Building2 size={21} />
            </span>
            <span>Rent<span>Sure</span></span>
          </Link>
        </header>

        <section className="property-content property-access-denied">
          <CircleAlert size={35} />
          <h1>Landlord access required</h1>
          <p>Sign in with a landlord account to manage property listings.</p>
          <Link to="/login" className="property-nav-cta">
            Sign in
          </Link>
        </section>
      </main>
    );
  }

  return (
    <main className="property-page">
      <header className="property-topbar">
        <Link to="/" className="property-brand">
          <span className="property-brand-icon">
            <Building2 size={21} />
          </span>
          <span>Rent<span>Sure</span></span>
        </Link>

        <nav className="property-topbar-actions">
          <Link to="/dashboard" className="property-nav-link">
            <ArrowLeft size={15} />
            Dashboard
          </Link>

          <Link to="/properties" className="property-nav-cta">
            Browse rentals
          </Link>
        </nav>
      </header>

      <section className="landlord-property-hero">
        <div>
          <div className="property-eyebrow">
            <span />
            LANDLORD WORKSPACE
          </div>

          <h1>
            Your properties.
            <br />
            <span>Your control.</span>
          </h1>

          <p>
            Manage rental listings, keep details up to date, and make
            your properties discoverable to tenants.
          </p>
        </div>

        <div className="landlord-property-count">
          <Building2 size={24} />
          <span>YOUR LISTINGS</span>
          <strong>{properties.length}</strong>
          <small>Properties in your account</small>
        </div>
      </section>

      <section className="property-content landlord-property-content">
        <div className="property-section-heading">
          <div>
            <span className="property-section-kicker">PROPERTY MANAGEMENT</span>
            <h2>{editingId ? "Edit property" : "Add a property"}</h2>
            <p>
              {editingId
                ? "Update the listing details below."
                : "Enter accurate details to publish a rental listing."}
            </p>
          </div>
        </div>

        <div id="property-editor" className="landlord-property-editor">
          <form className="landlord-property-form" onSubmit={handleSubmit}>
            <div className="landlord-form-grid">
              <label className="landlord-form-field">
                <span>Property type</span>
                <select name="propertyType" value={form.propertyType} onChange={updateField} required>
                  <option value="pg">PG / Paying Guest</option>
                  <option value="flat">Flat / Apartment</option>
                  <option value="house">Independent house</option>
                  <option value="villa">Villa</option>
                  <option value="other">Other</option>
                </select>
              </label>

              <label className="landlord-form-field">
                <span>Property title</span>
                <input
                  name="title"
                  value={form.title}
                  onChange={updateField}
                  placeholder="e.g. Furnished PG near university"
                  maxLength={160}
                  required
                />
              </label>

              <label className="landlord-form-field landlord-field-full">
                <span>Description</span>
                <textarea
                  name="description"
                  value={form.description}
                  onChange={updateField}
                  placeholder="Describe the property, rules, availability, and what is included."
                  maxLength={5000}
                  rows={4}
                />
              </label>

              <label className="landlord-form-field landlord-field-full">
                <span>Full address</span>
                <input
                  name="address"
                  value={form.address}
                  onChange={updateField}
                  placeholder="Street, sector, or neighbourhood"
                  maxLength={2000}
                  required
                />
              </label>

              <label className="landlord-form-field">
                <span>City</span>
                <input
                  name="city"
                  value={form.city}
                  onChange={updateField}
                  placeholder="e.g. Chandigarh"
                  maxLength={100}
                  required
                />
              </label>

              <label className="landlord-form-field">
                <span>Monthly rent (₹)</span>
                <input
                  name="monthlyRent"
                  type="number"
                  min="1"
                  step="0.01"
                  value={form.monthlyRent}
                  onChange={updateField}
                  placeholder="18000"
                  required
                />
              </label>

              <label className="landlord-form-field">
                <span>Security deposit (₹)</span>
                <input
                  name="securityDeposit"
                  type="number"
                  min="0"
                  step="0.01"
                  value={form.securityDeposit}
                  onChange={updateField}
                  placeholder="36000"
                  required
                />
              </label>

              <label className="landlord-form-field">
                <span>Bedrooms / rooms</span>
                <input name="bedrooms" type="number" min="0" max="100" step="1" value={form.bedrooms} onChange={updateField} placeholder="e.g. 2" />
              </label>

              <label className="landlord-form-field">
                <span>Bathrooms</span>
                <input name="bathrooms" type="number" min="0" max="100" step="1" value={form.bathrooms} onChange={updateField} placeholder="e.g. 2" />
              </label>

              <label className="landlord-form-field">
                <span>Area (sq ft)</span>
                <input name="area" type="number" min="0" step="0.01" value={form.area} onChange={updateField} placeholder="e.g. 850" />
              </label>

              <label className="landlord-form-field">
                <span>Furnishing</span>
                <select name="furnishing" value={form.furnishing} onChange={updateField}>
                  <option value="unfurnished">Unfurnished</option>
                  <option value="semi-furnished">Semi-furnished</option>
                  <option value="furnished">Furnished</option>
                </select>
              </label>

              <label className="landlord-form-field landlord-field-full">
                <span>Amenities (comma-separated)</span>
                <input name="amenities" value={form.amenities} onChange={updateField} placeholder="Wi-Fi, meals, parking, laundry" maxLength={2000} />
              </label>
            </div>

            {error && (
              <div className="property-message property-error" role="alert">
                <CircleAlert size={17} />
                {error}
              </div>
            )}

            {notice && (
              <div className="property-message property-success" role="status">
                <Check size={17} />
                {notice}
              </div>
            )}

            <div className="landlord-form-actions">
              {editingId && (
                <button
                  type="button"
                  className="landlord-secondary-button"
                  onClick={resetForm}
                  disabled={saving}
                >
                  <X size={16} />
                  Cancel edit
                </button>
              )}

              <button
                type="submit"
                className="landlord-submit-button"
                disabled={saving}
              >
                {saving ? (
                  <RefreshCw size={16} className="property-spin" />
                ) : editingId ? (
                  <Save size={16} />
                ) : (
                  <Plus size={17} />
                )}

                {saving
                  ? "Saving..."
                  : editingId
                    ? "Save changes"
                    : "Create property"}
              </button>
            </div>
          </form>
        </div>

        <div className="property-section-heading landlord-list-heading">
          <div>
            <span className="property-section-kicker">YOUR INVENTORY</span>
            <h2>Managed properties</h2>
            <p>Only listings owned by your account appear here.</p>
          </div>

          <button
            type="button"
            className="property-refresh"
            onClick={loadProperties}
            disabled={loading}
          >
            <RefreshCw size={15} className={loading ? "property-spin" : ""} />
            Refresh
          </button>
        </div>

        {loading && <div className="property-loading-line">Loading your properties...</div>}

        {!loading && properties.length > 0 && (
          <div className="landlord-managed-list">
            {properties.map((property) => (
              <motion.article
                className="landlord-managed-card"
                key={property.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <div className="landlord-managed-icon">
                  <Building2 size={23} />
                </div>

                <div className="landlord-managed-info">
                  <h3>{property.title}</h3>
                  <p>
                    <MapPin size={13} />
                    {property.address}, {property.city}
                  </p>
                  <p className="landlord-property-meta">
                    {(property.propertyType || "flat").toUpperCase().replace("-", " ")}
                    {property.bedrooms != null ? ` · ${property.bedrooms} rooms` : ""}
                    {property.furnishing ? ` · ${property.furnishing}` : ""}
                  </p>
                  <div className="landlord-managed-prices">
                    <span>Rent: <strong>{money(property.monthlyRent)}</strong>/month</span>
                    <span>Deposit: <strong>{money(property.securityDeposit)}</strong></span>
                  </div>
                </div>

                <div
                  className="landlord-managed-actions"
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "flex-end",
                    flexWrap: "wrap",
                    gap: "10px",
                    marginTop: "12px",
                  }}
                >
                  <button
                    type="button"
                    className="landlord-edit-button"
                    onClick={() => startEditing(property)}
                    aria-label={`Edit ${property.title}`}
                    style={{
                      display: "inline-flex",
                      alignItems: "center",
                      justifyContent: "center",
                      gap: "7px",
                      padding: "10px 14px",
                      border: "1px solid #d9c4ff",
                      borderRadius: "10px",
                      background: "#f4e8ff",
                      color: "#7027e8",
                      fontWeight: 600,
                      cursor: "pointer",
                    }}
                  >
                    <Edit3 size={16} />
                    Edit
                  </button>

                  <button
                    type="button"
                    className="landlord-delete-button"
                    onClick={() => handleDelete(property)}
                    disabled={deletingId === property.id}
                    aria-label={`Delete ${property.title}`}
                    style={{
                      display: "inline-flex",
                      alignItems: "center",
                      justifyContent: "center",
                      gap: "7px",
                      padding: "10px 14px",
                      border: "1px solid #f0c6ce",
                      borderRadius: "10px",
                      background: "#fff1f2",
                      color: "#b42336",
                      fontWeight: 600,
                      cursor: deletingId === property.id ? "wait" : "pointer",
                      opacity: deletingId === property.id ? 0.65 : 1,
                    }}
                  >
                    {deletingId === property.id ? (
                      <RefreshCw size={16} className="property-spin" />
                    ) : (
                      <Trash2 size={16} />
                    )}
                    {deletingId === property.id ? "Deleting..." : "Delete"}
                  </button>
                </div>
              </motion.article>
            ))}
          </div>
        )}

        {!loading && properties.length === 0 && !error && (
          <div className="property-empty">
            <div className="property-empty-icon">
              <Building2 size={28} />
            </div>
            <h3>Your property list is empty</h3>
            <p>
              Create your first listing using the form above. It will be
              saved to PostgreSQL and appear in the public property browser.
            </p>
          </div>
        )}
      </section>

      <footer className="property-footer">
        <span>© {new Date().getFullYear()} RentSure</span>
        <span>Rent smarter. Move forward.</span>
      </footer>
    </main>
  );
}
