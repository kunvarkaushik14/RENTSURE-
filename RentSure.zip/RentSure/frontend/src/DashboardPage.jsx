
import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  ArrowRight,
  ArrowUpRight,
  Building2,
  CheckCircle2,
  ClipboardList,
  Compass,
  Home,
  LogOut,
  Plus,
  Search,
  ShieldCheck,
  Wallet,
  Heart,
  Sparkles,
  TrendingUp,
} from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "./AuthContext";
import api from "./api";
import "./DashboardPage.css";

export default function DashboardPage() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const role = String(user?.role || "tenant").toLowerCase();
  const isLandlord = role === "landlord";
  const name = user?.fullName || user?.full_name || "RentSure User";
  const firstName = name.trim().split(/\s+/)[0] || "there";

  const [myProperties, setMyProperties] = useState([]);
  const [propertiesLoading, setPropertiesLoading] = useState(isLandlord);

  useEffect(() => {
    let active = true;

    async function loadProperties() {
      if (!isLandlord) {
        setPropertiesLoading(false);
        return;
      }

      try {
        const result = await api.get("/properties/mine");
        const rows = Array.isArray(result)
          ? result
          : result?.properties || result?.data?.properties || result?.data || [];

        if (active) {
          setMyProperties(Array.isArray(rows) ? rows : []);
        }
      } catch {
        if (active) setMyProperties([]);
      } finally {
        if (active) setPropertiesLoading(false);
      }
    }

    loadProperties();

    return () => {
      active = false;
    };
  }, [isLandlord]);

  const savedCount = useMemo(() => {
    try {
      const saved = JSON.parse(
        localStorage.getItem("rentsure_favorites") || "[]"
      );
      return Array.isArray(saved) ? saved.length : 0;
    } catch {
      return 0;
    }
  }, []);

  function handleLogout() {
    logout();
    navigate("/login", { replace: true });
  }

  const stats = isLandlord
    ? [
        {
          label: "Your listings",
          value: propertiesLoading ? "…" : myProperties.length,
          note: "Properties in your workspace",
          icon: Building2,
        },
        {
          label: "Applications",
          value: "—",
          note: "Application tracking is not connected yet",
          icon: ClipboardList,
        },
        {
          label: "Rental income",
          value: "—",
          note: "Income reporting is not connected yet",
          icon: TrendingUp,
        },
      ]
    : [
        {
          label: "Saved properties",
          value: savedCount,
          note: "Homes saved in this browser",
          icon: Heart,
        },
        {
          label: "Applications",
          value: "—",
          note: "Application tracking is not connected yet",
          icon: ClipboardList,
        },
        {
          label: "Deposit planning",
          value: "Ready",
          note: "Estimate your upfront rental costs",
          icon: Wallet,
        },
      ];

  const actions = isLandlord
    ? [
        {
          title: "Manage your listings",
          detail: "Review, edit, or remove properties you have published.",
          icon: Building2,
          to: "/my-properties",
          label: "Open my properties",
        },
        {
          title: "Publish a property",
          detail: "Add rent, location, amenities, and property details.",
          icon: Plus,
          to: "/my-properties",
          label: "Add a listing",
        },
        {
          title: "Preview the marketplace",
          detail: "See how your rental appears to people searching.",
          icon: Search,
          to: "/properties",
          label: "Browse properties",
        },
      ]
    : [
        {
          title: "Find your next home",
          detail: "Explore listings by location, rent, and property type.",
          icon: Search,
          to: "/properties",
          label: "Explore properties",
        },
        {
          title: "Your saved places",
          detail: "Return to properties you have saved for later.",
          icon: Heart,
          to: "/properties",
          label: "View properties",
        },
        {
          title: "Plan your deposit",
          detail: "Estimate the upfront amount you may need before moving.",
          icon: Wallet,
          to: "/#calculator",
          label: "Open calculator",
        },
      ];

  return (
    <main
      className={`dashboard-page ${
        isLandlord ? "dashboard-landlord" : "dashboard-tenant"
      }`}
    >
      <aside className="dashboard-sidebar" aria-label="Main navigation">
        <Link
          to="/dashboard"
          className="dashboard-brand"
          aria-label="RentSure dashboard"
        >
          <span className="dashboard-brand-icon">
            <Home size={21} strokeWidth={2.2} />
          </span>
          <span className="dashboard-brand-word">
            Rent<span>Sure</span>
          </span>
        </Link>

        <div className="dashboard-sidebar-label">YOUR WORKSPACE</div>

        <nav className="dashboard-nav" aria-label="Workspace">
          <Link
            to="/dashboard"
            className="dashboard-nav-item active"
            aria-current="page"
          >
            <Building2 size={18} />
            <span>Overview</span>
          </Link>

          <Link to="/properties" className="dashboard-nav-item">
            <Compass size={18} />
            <span>Find Properties</span>
            <ArrowUpRight
              size={15}
              className="dashboard-property-arrow"
            />
          </Link>

          {isLandlord ? (
            <Link to="/my-properties" className="dashboard-nav-item">
              <ClipboardList size={18} />
              <span>My properties</span>
              <ArrowUpRight
                size={15}
                className="dashboard-property-arrow"
              />
            </Link>
          ) : (
            <Link to="/properties" className="dashboard-nav-item">
              <Heart size={18} />
              <span>Saved homes</span>
            </Link>
          )}

          <a className="dashboard-nav-item" href="/#calculator">
            <Wallet size={18} />
            <span>Deposit plans</span>
          </a>
        </nav>

        <div className="dashboard-sidebar-bottom">
          <div className="dashboard-security">
            <span className="dashboard-security-icon">
              <ShieldCheck size={19} />
            </span>
            <div>
              <strong>Account secured</strong>
              <span>Your session is protected</span>
            </div>
          </div>

          <button
            className="dashboard-logout"
            onClick={handleLogout}
            type="button"
          >
            <LogOut size={17} />
            <span>Sign out</span>
          </button>
        </div>
      </aside>

      <section className="dashboard-main">
        <header className="dashboard-topbar">
          <div className="dashboard-heading">
            <span className="dashboard-breadcrumb">
              WORKSPACE <span>/</span> {isLandlord ? "LANDLORD" : "TENANT"}
            </span>

            <h1>
              {isLandlord ? "Landlord dashboard" : "Tenant dashboard"}
            </h1>

            <p className="dashboard-topbar-subtitle">
              {isLandlord
                ? "Your properties, organised in one place."
                : "Your search for a better rental starts here."}
            </p>
          </div>

          <div className="dashboard-user">
            <div className="dashboard-avatar" aria-hidden="true">
              {name.charAt(0).toUpperCase()}
            </div>
            <div className="dashboard-user-info">
              <strong>{name}</strong>
              <span>{isLandlord ? "Landlord" : "Tenant"}</span>
            </div>
            <span className="dashboard-user-status" title="Signed in" />
          </div>
        </header>

        <motion.section
          className="dashboard-welcome"
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45 }}
        >
          <div className="dashboard-welcome-copy">
            <div className="dashboard-welcome-tag">
              <span className="dashboard-status-dot" />
              {isLandlord ? "LANDLORD WORKSPACE" : "YOUR RENTAL JOURNEY"}
            </div>

            <h2>
              {isLandlord ? (
                <>
                  Welcome back,
                  <br />
                  <span>{firstName}.</span>
                </>
              ) : (
                <>
                  Your next home
                  <br />
                  <span>starts here, {firstName}.</span>
                </>
              )}
            </h2>

            <p>
              {isLandlord
                ? "Manage your published listings, keep property information up to date, and preview what renters can see."
                : "Discover places that fit your lifestyle, save promising listings, and plan your move with more confidence."}
            </p>

            <Link
              to={isLandlord ? "/my-properties" : "/properties"}
              className="dashboard-primary-link"
            >
              {isLandlord ? "Manage my properties" : "Explore properties"}
              <ArrowRight size={17} />
            </Link>

            <div className="dashboard-welcome-note">
              <ShieldCheck size={15} />
              Your {isLandlord ? "landlord" : "tenant"} workspace is active
            </div>
          </div>

          <div className="dashboard-welcome-graphic" aria-hidden="true">
            <div className="dashboard-graphic-orbit orbit-one" />
            <div className="dashboard-graphic-orbit orbit-two" />
            <div className="dashboard-graphic-orbit orbit-three" />

            <motion.div
              className="dashboard-house-icon"
              animate={{ y: [0, -7, 0] }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            >
              {isLandlord ? (
                <Building2 size={45} strokeWidth={1.6} />
              ) : (
                <Home size={48} strokeWidth={1.55} />
              )}
            </motion.div>

            <div className="dashboard-graphic-chip">
              <Sparkles size={15} />
              {isLandlord
                ? "Your listings, your control"
                : "Find a place to belong"}
            </div>

            <span className="dashboard-graphic-spark spark-one">✦</span>
            <span className="dashboard-graphic-spark spark-two">✧</span>
          </div>
        </motion.section>

        <section
          className="dashboard-overview-section"
          aria-labelledby="overview-title"
        >
          <div className="dashboard-section-heading">
            <div>
              <span className="dashboard-eyebrow">AT A GLANCE</span>
              <h2 id="overview-title">
                {isLandlord
                  ? "Your property overview"
                  : "Your rental overview"}
              </h2>
              <p>
                {isLandlord
                  ? "A quick look at the listings you manage."
                  : "A quick look at your saved places and next steps."}
              </p>
            </div>

            <span className="dashboard-live-status">
              <span className="dashboard-status-dot" />
              ACCOUNT ACTIVE
            </span>
          </div>

          <div className="dashboard-stats">
            {stats.map((stat, index) => {
              const Icon = stat.icon;

              return (
                <motion.article
                  className="dashboard-stat-card"
                  key={stat.label}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.08 }}
                  whileHover={{ y: -4 }}
                >
                  <div className="dashboard-stat-top">
                    <span className="dashboard-stat-icon">
                      <Icon size={20} />
                    </span>
                    <ArrowUpRight
                      size={17}
                      className="dashboard-stat-arrow"
                    />
                  </div>
                  <p>{stat.label}</p>
                  <strong className="dashboard-stat-value">
                    {stat.value}
                  </strong>
                  <small>{stat.note}</small>
                </motion.article>
              );
            })}
          </div>
        </section>

        <section className="dashboard-actions-section">
          <div className="dashboard-section-heading">
            <div>
              <span className="dashboard-eyebrow">QUICK ACTIONS</span>
              <h2>
                {isLandlord
                  ? "Keep your rentals moving"
                  : "Make your next move"}
              </h2>
              <p>
                {isLandlord
                  ? "Pick up where you left off."
                  : "Useful shortcuts for your rental search."}
              </p>
            </div>
          </div>

          <div className="dashboard-action-grid">
            {actions.map((action, index) => {
              const Icon = action.icon;

              return (
                <motion.article
                  className="dashboard-action-card"
                  key={action.title}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.12 + index * 0.08 }}
                  whileHover={{ y: -4 }}
                >
                  <span className="dashboard-action-icon">
                    <Icon size={21} />
                  </span>
                  <h3>{action.title}</h3>
                  <p>{action.detail}</p>
                  <Link to={action.to}>
                    {action.label}
                    <ArrowRight size={15} />
                  </Link>
                </motion.article>
              );
            })}
          </div>
        </section>

        <motion.section
          className="dashboard-next-card"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <div className="dashboard-next-icon">
            <CheckCircle2 size={23} />
          </div>
          <div className="dashboard-next-copy">
            <span className="dashboard-eyebrow">YOUR WORKSPACE</span>
            <h3>
              {isLandlord
                ? "Your listings are within reach"
                : "Your rental search starts here"}
            </h3>
            <p>
              {isLandlord
                ? "Open My properties to add a listing or manage properties you have already published."
                : "Browse available properties, save the ones you like, and return to your dashboard whenever you need."}
            </p>
          </div>
          <Link className="dashboard-back-link" to="/dashboard">
            Dashboard home
          </Link>
        </motion.section>

        <footer className="dashboard-footer">
          <span>© {new Date().getFullYear()} RentSure</span>
          <span>Rent smarter. Move forward.</span>
        </footer>
      </section>
    </main>
  );
}
